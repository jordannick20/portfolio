import pygame
import random
import asyncio
print("game starting")


pygame.init()

# -----------------------------
# BASIC CONSTANTS & GLOBALS
# -----------------------------
collision_boxes = [
    pygame.Rect(692, 273, 200, 40),
]

show_frame = False
frame_start_time = 0

wave_last_time = 0
wave_delay = 15000
zombie_speed = 1.7
spawn_delay = 2000

menu_options = ["Restart", "Main Menu", "Quit"]
selected_option = 0

dead_zombies = 0

SHOW_TIME = 660
WIDTH, HEIGHT = 1000, 750

MAX_AMMO = 30
ammo = MAX_AMMO

is_reloading = False
reload_frame_index = 0

difficulty = "Normal"

LEFT_BORDER = 0
RIGHT_BORDER = 870
TOP_BORDER = 235
BOTTOM_BORDER = 515

bullets = []
zombies = []
blood_splatters = []

screen = pygame.display.set_mode((WIDTH, HEIGHT))
font = pygame.font.SysFont(None, 40)
clock = pygame.time.Clock()

# -----------------------------
# LOAD IMAGES
# -----------------------------
game_bg = pygame.image.load("gameimage.png").convert()
death_menu_img = pygame.image.load("youdead.png").convert()
sprite_sheet = pygame.image.load("Walk.png").convert_alpha()
shoot_sheet = pygame.image.load("Shot_2.png").convert_alpha()
zombie_sheet = pygame.image.load("Walkzombie.png").convert_alpha()
zombiedead_sheet = pygame.image.load("Deadzombie.png").convert_alpha()
zombieattack_sheet = pygame.image.load("Attack_1.png").convert_alpha()
playerdead_sheet = pygame.image.load("Dead.png").convert_alpha()
blood_sheet = pygame.image.load("blood.png").convert_alpha()
reload_sheet = pygame.image.load("Recharge.png").convert_alpha()

# -----------------------------
# FRAME LOADER
# -----------------------------
def load_frames(sheet, frame_width, frame_height, num_frames):
    frames = []
    for i in range(num_frames):
        frame = sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, frame_height))
        frames.append(frame)
    return frames

# -----------------------------
# ANIMATIONS
# -----------------------------
walk_frames = load_frames(sprite_sheet, 128, 66, 8)
shoot_frames = load_frames(shoot_sheet, 128, 66, 4)
zombie_frames = load_frames(zombie_sheet, 96, 67, 8)
zombiedead_frames = load_frames(zombiedead_sheet, 96, 67, 5)
zombie_attack_frames = load_frames(zombieattack_sheet, 96, 67, 5)
player_death_frames = load_frames(playerdead_sheet, 128, 67, 4)
blood_frames = load_frames(blood_sheet, 96, 67, 4)
reload_frames = load_frames(reload_sheet, 128, 80, 13)

# -----------------------------
# PLAYER STATE
# -----------------------------
player_x = WIDTH // 2
player_y = HEIGHT // 2
player_speed = 4
frame_index = 0
animation_speed = 0.3
facing_left = False
current_frame = walk_frames[0]

# ---------------------------------------------------------
# ASYNC START SCREEN
# ---------------------------------------------------------
async def show_start_screen(screen, image_path):
    start_img = pygame.image.load(image_path).convert()

    start_rect = pygame.Rect(398, 415, 200, 70)
    options_rect = pygame.Rect(398, 495, 200, 70)
    quit_rect = pygame.Rect(398, 574, 200, 70)

    while True:
        screen.blit(start_img, (0, 0))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()

                if start_rect.collidepoint(mouse_pos):
                    return "start"

                if options_rect.collidepoint(mouse_pos):
                    return "options"

                if quit_rect.collidepoint(mouse_pos):
                    return "quit"

        await asyncio.sleep(0)


# ---------------------------------------------------------
# ASYNC OPTIONS MENU
# ---------------------------------------------------------
async def show_options_menu(screen):
    option_font = pygame.font.SysFont(None, 55)
    difficulty_options = ["Easy", "Normal", "Hard", "Back"]
    selected = 0

    while True:
        screen.fill((136, 0, 21))

        title = option_font.render("Select Difficulty", True, (255, 255, 255))
        screen.blit(title, (320, 150))

        for i, opt in enumerate(difficulty_options):
            text = "> " + opt if i == selected else opt
            render = option_font.render(text, True, (255, 255, 255))
            screen.blit(render, (350, 300 + i * 70))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None

            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_UP, pygame.K_w]:
                    selected = (selected - 1) % len(difficulty_options)

                if event.key in [pygame.K_DOWN, pygame.K_s]:
                    selected = (selected + 1) % len(difficulty_options)

                if event.key == pygame.K_RETURN:
                    choice = difficulty_options[selected]
                    return choice

        await asyncio.sleep(0)

# ---------------------------------------------------------
# ZOMBIE CLASS
# ---------------------------------------------------------
class Zombie:
    def __init__(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed
        self.health = 3
        self.width = 96
        self.height = 67
        self.alive = True
        self.dying = False

        self.walk_index = 0
        self.death_index = 0

        self.facing_left = True if x > WIDTH // 2 else False

    def update(self, player_x, player_y):
        if self.alive:
            dx = player_x - self.x
            dy = player_y - self.y
            distance = max(1, (dx**2 + dy**2) ** 0.5)

            self.x += (dx / distance) * self.speed
            self.y += (dy / distance) * self.speed

            self.facing_left = dx < 0

            self.walk_index += 0.2
            if self.walk_index >= len(zombie_frames):
                self.walk_index = 0

        elif self.dying:
            self.death_index += 0.25
            if self.death_index >= len(zombiedead_frames):
                self.dying = False

    def draw(self, screen):
        if self.alive:
            frame = zombie_frames[int(self.walk_index)]
        elif self.dying:
            frame = zombiedead_frames[int(self.death_index)]
        else:
            return

        if self.facing_left:
            frame = pygame.transform.flip(frame, True, False)

        screen.blit(frame, (self.x, self.y))


# ---------------------------------------------------------
# BULLET CLASS
# ---------------------------------------------------------
class Bullet:
    def __init__(self, x, y, direction):
        self.x = x
        self.y = y
        self.speed = 30
        self.direction = direction
        self.width = 8
        self.height = 2

    def update(self):
        if self.direction:
            self.x -= self.speed
        else:
            self.x += self.speed

    def draw(self, screen):
        pygame.draw.rect(screen, (255, 255, 0), (self.x, self.y, self.width, self.height))


# ---------------------------------------------------------
# BLOOD SPLATTER CLASS
# ---------------------------------------------------------
class BloodSplatter:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.frame_index = 0
        self.finished = False

    def update(self):
        self.frame_index += 0.3
        if self.frame_index >= len(blood_frames):
            self.finished = True

    def draw(self, screen):
        if not self.finished:
            frame = blood_frames[int(self.frame_index)]
            screen.blit(frame, (self.x - 20, self.y - 20))


# ---------------------------------------------------------
# RESET GAME
# ---------------------------------------------------------
def reset_game():
    global facing_left
    global last_spawn_time
    global wave_last_time
    global player_x, player_y
    global bullets, zombies, blood_splatters
    global ammo
    global game_state
    global death_frame_index
    global attack_frame_index
    global killer_zombie
    global selected_option
    global is_reloading
    global is_shooting
    global dead_zombies
    global zombie_speed, spawn_delay, wave_delay

    # Difficulty settings
    if difficulty == "Easy":
        spawn_delay = 3000
        wave_delay = 20000
        zombie_speed = 1.2
    elif difficulty == "Normal":
        spawn_delay = 2000
        wave_delay = 15000
        zombie_speed = 1.7
    elif difficulty == "Hard":
        spawn_delay = 1500
        wave_delay = 10000
        zombie_speed = 2.0

    player_x = WIDTH // 2
    player_y = HEIGHT // 2

    bullets.clear()
    zombies.clear()
    blood_splatters.clear()

    ammo = MAX_AMMO
    dead_zombies = 0

    death_frame_index = 0
    attack_frame_index = 0

    killer_zombie = None

    is_reloading = False
    is_shooting = False

    selected_option = 0

    game_state = "playing"
    last_spawn_time = pygame.time.get_ticks()
    wave_last_time = pygame.time.get_ticks()

# ---------------------------------------------------------
# ASYNC MAIN GAME LOOP
# ---------------------------------------------------------
async def main_game_loop():
    global facing_left
    global player_x, player_y, frame_index, current_frame
    global is_reloading, reload_frame_index
    global is_shooting, shoot_frame_index
    global game_state, selected_option
    global attack_frame_index, death_frame_index, killer_zombie
    global ammo, dead_zombies, bullets, zombies, blood_splatters
    global show_frame, frame_start_time, last_spawn_time, wave_last_time

    running = True
    game_state = "playing"

    shoot_frame_index = 0
    attack_frame_index = 0
    death_frame_index = 0
    killer_zombie = None

    while running:

        # -------------------------
        # EVENT LOOP
        # -------------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                # PLAYING CONTROLS
                if game_state == "playing":

                    # reload
                    if event.key == pygame.K_r:
                        if ammo < MAX_AMMO and not is_reloading:
                            is_reloading = True
                            reload_frame_index = 0

                    # shoot
                    if event.key == pygame.K_SPACE:
                        if ammo > 0 and not is_reloading:
                            bullet_x = player_x + current_frame.get_width() // 2
                            bullet_y = player_y + current_frame.get_height() // 2 - 17
                            bullets.append(Bullet(bullet_x, bullet_y, facing_left))
                            ammo -= 1
                            is_shooting = True
                            shoot_frame_index = 0

                # DEATH MENU CONTROLS
                if game_state == "death_menu":
                    if event.key in [pygame.K_UP, pygame.K_w]:
                        selected_option = (selected_option - 1) % len(menu_options)

                    if event.key in [pygame.K_DOWN, pygame.K_s]:
                        selected_option = (selected_option + 1) % len(menu_options)

                    if event.key == pygame.K_RETURN:
                        choice = menu_options[selected_option]

                        if choice == "Restart":
                            reset_game()

                        elif choice == "Main Menu":
                            return "menu"

                        elif choice == "Quit":
                            running = False

        # -------------------------
        # MOVEMENT
        # -------------------------
        old_x, old_y = player_x, player_y
        keys = pygame.key.get_pressed()
        moving = False

        if game_state == "playing" and not is_shooting and not is_reloading:
            if keys[pygame.K_LEFT]:
                player_x -= player_speed
                moving = True
                facing_left = True

            if keys[pygame.K_RIGHT]:
                player_x += player_speed
                moving = True
                facing_left = False

            if keys[pygame.K_UP]:
                player_y -= player_speed
                moving = True

            if keys[pygame.K_DOWN]:
                player_y += player_speed
                moving = True

        # -------------------------
        # PLAYER HITBOX
        # -------------------------
        HITBOX_WIDTH = 25
        HITBOX_HEIGHT = 70

        player_hitbox = pygame.Rect(
            player_x + (128 - HITBOX_WIDTH) // 2,
            player_y + (66 - HITBOX_HEIGHT),
            HITBOX_WIDTH,
            HITBOX_HEIGHT
        )

        # -------------------------
        # COLLISION WITH MAP
        # -------------------------
        for box in collision_boxes:
            if player_hitbox.colliderect(box):
                player_x, player_y = old_x, old_y
                player_hitbox.topleft = (player_x, player_y)

        # -------------------------
        # ANIMATION
        # -------------------------
        if is_reloading:
            reload_frame_index += 0.35
            if reload_frame_index >= len(reload_frames):
                reload_frame_index = 0
                is_reloading = False
                ammo = MAX_AMMO
            current_frame = reload_frames[int(reload_frame_index)]

        elif is_shooting:
            shoot_frame_index += 0.6
            if shoot_frame_index >= len(shoot_frames):
                shoot_frame_index = 0
                is_shooting = False
            current_frame = shoot_frames[int(shoot_frame_index)]

        else:
            if moving:
                frame_index += animation_speed
                if frame_index >= len(walk_frames):
                    frame_index = 0
            else:
                frame_index = 0
            current_frame = walk_frames[int(frame_index)]

        if facing_left:
            current_frame = pygame.transform.flip(current_frame, True, False)

        # -------------------------
        # SPAWNING
        # -------------------------
        current_time = pygame.time.get_ticks()

        # normal spawn
        if current_time > 4000 and current_time - last_spawn_time > spawn_delay:
            side = random.choice(["left", "right"])
            spawn_x = -100 if side == "left" else WIDTH + 100
            spawn_y = random.randint(250, 400)
            zombies.append(Zombie(spawn_x, spawn_y, zombie_speed))
            last_spawn_time = current_time

        # horde waves
        if current_time > 7000 and current_time - wave_last_time > wave_delay:
            horde_size = random.randint(3, 8)
            for _ in range(horde_size):
                side = random.choice(["left", "right"])
                spawn_x = -100 if side == "left" else WIDTH + 100
                offset_x = random.randint(-40, 40)
                offset_y = random.randint(-40, 60)
                spawn_y = random.randint(250, 400) + offset_y
                zombies.append(Zombie(spawn_x + offset_x, spawn_y, zombie_speed))
            wave_last_time = current_time

        # -------------------------
        # UPDATE BULLETS
        # -------------------------
        for bullet in bullets:
            bullet.update()

        bullets = [b for b in bullets if 0 < b.x < WIDTH]

        # -------------------------
        # BULLET COLLISION
        # -------------------------
        for bullet in bullets[:]:
            for z in zombies:
                if z.alive:
                    zombie_rect = pygame.Rect(
                        z.x + (96 - 50) // 2,
                        z.y + (67 - 61),
                        50,
                        70
                    )
                    bullet_rect = pygame.Rect(bullet.x, bullet.y, bullet.width, bullet.height)

                    if bullet_rect.colliderect(zombie_rect):
                        z.health -= 1
                        blood_splatters.append(BloodSplatter(bullet.x, bullet.y))

                        if z.health <= 0:
                            z.alive = False
                            z.dying = True
                            dead_zombies += 1

                        bullets.remove(bullet)
                        break

        # -------------------------
        # UPDATE ZOMBIES
        # -------------------------
        if game_state == "playing":
            for z in zombies:
                z.update(player_x, player_y)

        # -------------------------
        # ZOMBIE ATTACK CHECK
        # -------------------------
        if game_state == "playing":
            for z in zombies:
                if z.alive:
                    zombie_rect = pygame.Rect(
                        z.x + (96 - 50) // 2,
                        z.y + (67 - 61),
                        50,
                        55
                    )
                    if zombie_rect.colliderect(player_hitbox):
                        game_state = "zombie_attack"
                        attack_frame_index = 0
                        death_frame_index = 0
                        killer_zombie = z
                        show_frame = True
                        frame_start_time = pygame.time.get_ticks()
                        break

        # -------------------------
        # BLOOD UPDATE
        # -------------------------
        for blood in blood_splatters:
            blood.update()

        blood_splatters = [b for b in blood_splatters if not b.finished]

        # -------------------------
        # BORDERS
        # -------------------------
        if player_x < LEFT_BORDER:
            player_x = LEFT_BORDER
        if player_x > RIGHT_BORDER - current_frame.get_width():
            player_x = RIGHT_BORDER - current_frame.get_width()
        if player_y < TOP_BORDER:
            player_y = TOP_BORDER
        if player_y > BOTTOM_BORDER - current_frame.get_height():
            player_y = BOTTOM_BORDER - current_frame.get_height()

        # -------------------------
        # DRAW EVERYTHING
        # -------------------------
        screen.blit(game_bg, (0, 0))

        for bullet in bullets:
            bullet.draw(screen)

        for z in zombies:
            if game_state == "playing" or z is not killer_zombie:
                z.draw(screen)

        # state drawing
        the_time = pygame.time.get_ticks()
        if the_time - frame_start_time > SHOW_TIME:
            show_frame = False

        if game_state == "playing":
            screen.blit(current_frame, (player_x, player_y))

        elif game_state == "zombie_attack":
            attack_frame_index += 0.25
            if attack_frame_index >= len(zombie_attack_frames):
                attack_frame_index = 0
                game_state = "player_dead"
                death_frame_index = 0

            attack_frame = zombie_attack_frames[int(attack_frame_index)]
            if killer_zombie.facing_left:
                attack_frame = pygame.transform.flip(attack_frame, True, False)

            screen.blit(attack_frame, (killer_zombie.x, killer_zombie.y))

        elif game_state == "player_dead":
            death_frame_index += 0.25
            if death_frame_index >= len(player_death_frames):
                death_frame_index = len(player_death_frames) - 1
                game_state = "death_menu"

            death_frame = player_death_frames[int(death_frame_index)]
            if facing_left:
                death_frame = pygame.transform.flip(death_frame, True, False)

            screen.blit(death_frame, (player_x, player_y))

        elif game_state == "death_menu":
            screen.blit(death_menu_img, (0, 0))
            option_font = pygame.font.SysFont(None, 55)

            for i, option in enumerate(menu_options):
                text = "> " + option if i == selected_option else option
                render = option_font.render(text, True, (255, 255, 255))
                screen.blit(render, (350, 300 + i * 80))

        # blood
        for blood in blood_splatters:
            blood.draw(screen)

        # ammo
        if game_state == "playing":
            ammo_text = font.render(f"Ammo: {ammo}/30", True, (255, 255, 255))
            screen.blit(ammo_text, (20, 20))

        # zombies killed
        zombies_killed_text = font.render(f"Zombies Killed {dead_zombies}", True, (255, 255, 255))
        screen.blit(zombies_killed_text, (370, 20))

        pygame.display.flip()

        # async tick
        await asyncio.sleep(1/45)


# ---------------------------------------------------------
# MAIN ENTRY POINT
# ---------------------------------------------------------
async def main():
    global difficulty

    while True:
        choice = await show_start_screen(screen, "stand_your_ground_1000x750.png")

        if choice == "quit":
            return

        if choice == "options":
            new_diff = await show_options_menu(screen)
            if new_diff and new_diff != "Back":
                difficulty = new_diff
            continue

        if choice == "start":
            reset_game()
            result = await main_game_loop()

            if result == "menu":
                continue
            else:
                return


# Run async game
if __name__ == "__main__":
    asyncio.run(main())






